#!/bin/bash


mpiexec -n 8 ./parallel < ./data/testdata2

