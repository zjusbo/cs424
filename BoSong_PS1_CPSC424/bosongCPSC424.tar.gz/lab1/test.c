#include <stdio.h>
#include <math.h>

int main(int argc, char ** argv){
  double a = pow(2.3, 3.3);
  printf("%f", a);

  return 0;
}
