#include <stdio.h>

int dummyq2(double* a){
  printf("this is a dummy function.\n");
  a[0] = 3;
  return 0;
}
