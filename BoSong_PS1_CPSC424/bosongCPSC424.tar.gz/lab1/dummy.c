#include <stdio.h>

int dummy(){
  printf("this is a dummy function.\n");
  return 0;
}
